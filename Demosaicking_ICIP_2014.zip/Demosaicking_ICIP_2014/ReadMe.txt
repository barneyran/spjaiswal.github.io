Author:

Sunil Jaiswal
Dept. of ECE, HKUST, Hong Kong
Email:spjaiswal@ust.hk

---------------------------------------------------------------------------

1) run file : main.m

2) Array Pattern

             G R 
             B G 

3) In main.m , final_output is the reconstructed RGB image
---------------------------------------------------------------------------

Project page : http://ihome.ust.hk/~spjaiswal/color_demosaicing.html

---------------------------------------------------------------------------

Please cite the paper if you use our code :

Jaiswal, S.P.; Au, O.C.; Jakhetiya, V.; Yuan Yuan; Haiyan Yang, "Exploitation of inter-color correlation for color image demosaicking," Image Processing (ICIP), 2014 IEEE International Conference on , vol., no., pp.1812,1816, 27-30 Oct. 2014
doi: 10.1109/ICIP.2014.7025363

---------------------------------------------------------------------------

