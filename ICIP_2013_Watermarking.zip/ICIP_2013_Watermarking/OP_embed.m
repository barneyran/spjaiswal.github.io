% Matlab code and data to reproduce results from the paper ::"EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING" .
% This software is provided for non-commercial and research purposes only.
% This code is written for the clarity of watermarking algorithm without considring the time complexity.
% Hope it will be useful, but without any warranty.

% Please cite the following paper if you use this code for research purpose:  
% Jaiswal, S. P., Au, O. C., Jakhetiya, V., Guo, Y., Tiwari, A. K., &  Yue, K. �EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING,�
% in International conference on Image Processing (ICIP), page 4540 - 4544 . IEEE, (2013). 

% Latest modifications: September, 2013.                     


%% 
function [out total] = OP_embed(ip,op,kkk, Q)

[x_i y_i] = size(ip);   %Getting parameters

total = 0;              %Initilizing the total capacity

I_out = double(zeros(x_i,y_i)); %Output image

ep_i = 3;
ep_j = 3;

% Q = input('Give the value of Q (1 implies Single Layer embedding, greater than 1 is for Multi-layer embedding -->');
l_i = 1;

tic

I_out(:,:)=op(:,:);      %Coping input image to output image

S = rand(1,1000000);
% 
for ii = 1: size(S,2)
    
    if S(ii) > 0.5
        
        S(ii) =0;
    else
        S(ii) =1;
        
    end
    
end
% S
%S should be a array of zeros and one
%In this part input should be like
%[1 0 1 1 1 1 0 0 0 1 0 0 0 1 1 0 1 0 0 1 0 1 1 0 0 0 0 1 1 0 1 0]

l_s = size(S,2);        %Length of S

Error_image = ip - op;
Error_image111 = Error_image;


  if (kkk == 1)  %% EVEN EVEN

        for i = 2:x_i-1
            for j = 2:y_i-1

                  if mod(i,2) == 0 && mod(j,2) == 0 %% EVEN EVEN
            
            
            
                        if Error_image(i,j) < Q && Error_image(i,j) >= -Q
        
                            total = total + 1;
        
                        end
        
                        %Now the actual process of embedding begains
        
                        if l_i <= l_s

                        %Data is available to embedd
                        value = S(1,l_i);
            
                        ep_i = i;
            
                        ep_j = j;
            
                        if ((Error_image(i,j)<Q) && (Error_image(i,j)>= -Q)) %% EMBEDDING

                            if value == 1   % 1 Embedd
                                if Error_image(i,j)>=0
                                    Error_image111(i,j) = Error_image111(i,j) + Q;
                                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                                else
                    
                                    Error_image111(i,j) = Error_image111(i,j) - Q;
                                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                                end
                            else            % 0 Embedd
                                if Error_image(i,j)>=0
                                    Error_image111(i,j) = Error_image111(i,j);
                                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                                else
                    
                                    Error_image111(i,j) = Error_image111(i,j) ;
                                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                                end 
                    
                    
                            end
                                l_i = l_i + 1;
            
                       else        %% HISTOGRAM SHIFTING
                                if Error_image(i,j)>=Q
                        
                                    Error_image111(i,j) = Error_image111(i,j) + Q;
                                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                                else if Error_image(i,j)< -Q
                                    Error_image111(i,j) = Error_image111(i,j) - Q;
                                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                                    end
                                end
                        end
            
                        end
                  end
        
            end
      
       end

  end
            

  if (kkk == 2)  %% EVEN odd
total = 0;
for i = 2:x_i-1
    for j = 2:y_i-1

              if mod(i,2) == 0 && mod(j,2) ~= 0 %% EVEN EVEN
            
            
           
        if Error_image(i,j) < Q && Error_image(i,j) >= -Q
        
            total = total + 1;
        
        end
        
        %Now the actual process of embedding begains
        
        if l_i <= l_s

            %Data is available to embedd
            value = S(1,l_i);
            
            ep_i = i;
            
            ep_j = j;
            
            if ((Error_image(i,j)<Q) && (Error_image(i,j)>= -Q))

                if value == 1
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
                else
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j);
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) ;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end 
                    
                    
                end
                l_i = l_i + 1;
            
            else
                    if Error_image(i,j)>0
                        
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    else
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
            end
            
        end
              end
        
    end
    
end
  end
            

  if (kkk == 3)  %%  odd EVEN
total = 0;
for i = 2:x_i-1
    for j = 2:y_i-1

              if mod(i,2) ~= 0 && mod(j,2) == 0 %% EVEN EVEN
            
            
           
        if Error_image(i,j) < Q && Error_image(i,j) >= -Q
        
            total = total + 1;
        
        end
        
        %Now the actual process of embedding begins
        
        if l_i <= l_s

            %Data is available to embedd
            value = S(1,l_i);
            
            ep_i = i;
            
            ep_j = j;
            
            if ((Error_image(i,j)<Q) && (Error_image(i,j)>= -Q))

                if value == 1
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
                else
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j);
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) ;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end 
                    
                    
                end
                l_i = l_i + 1;
            
            else
                    if Error_image(i,j)>0
                        
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    else
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
            end
            
        end
        end
        
    end
    
end


  end          

  if (kkk == 4)  %% odd odd 

      total = 0;
      
for i = 2:x_i-1
    for j = 2:y_i-1

              if mod(i,2) ~= 0 && mod(j,2) ~= 0 %% EVEN EVEN
            
           
        if Error_image(i,j) < Q && Error_image(i,j) >= -Q
        
            total = total + 1;
        
        end
        
        %Now the actual process of embedding begains
        
        if l_i <= l_s

            %Data is available to embedd
            value = S(1,l_i);
            
            ep_i = i;
            
            ep_j = j;
            
            if ((Error_image(i,j)<Q) && (Error_image(i,j)>= -Q))

                if value == 1
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
                else
                    if Error_image(i,j)>=0
                        Error_image111(i,j) = Error_image111(i,j);
                    I_out(i,j) = I_out(i,j) +  Error_image111(i,j);
                    else
                    
                        Error_image111(i,j) = Error_image111(i,j) ;
                        I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end 
                    
                    
                end
                l_i = l_i + 1;
            
            else
                    if Error_image(i,j)>0
                        
                        Error_image111(i,j) = Error_image111(i,j) + Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    else
                        Error_image111(i,j) = Error_image111(i,j) - Q;
                    I_out(i,j) = I_out(i,j) + Error_image111(i,j);
                    end
            end
            
        end
        end
        
    end
    
end

  end
 
  

  
out = I_out;
total = total;


end