%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       ������֮֡���PSNR       
%%       author: ������ ( ganzongliang@hotmail )  
%%       Data:   2006��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SNR = PSNR(FrameOne,FrameTwo);

FrameOne = double(FrameOne);
FrameTwo = double(FrameTwo);
FrameOne = imcrop(FrameOne,[2 2 509 509]);
FrameTwo = imcrop(FrameTwo,[2 2 509 509]);
[w,h]=size(FrameOne);
MSE = sum((FrameOne(:)-FrameTwo(:)).^2);

TotalPixel = w*h;
[w h];
SNR = 10 * log10((255 * 255) / (MSE /TotalPixel));
% (MSE /TotalPixel)