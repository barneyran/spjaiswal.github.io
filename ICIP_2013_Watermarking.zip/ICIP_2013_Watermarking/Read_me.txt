Author:

Sunil Jaiswal
Dept. of ECE, HKUST, Hong Kong
Email:spjaiswal@ust.hk

---------------------------------------------------------------------------

1) run file : main.m

2) In main.m , oo_w is the final watermarked image
---------------------------------------------------------------------------

Project page : http://ihome.ust.hk/~spjaiswal/reversible_watermarking.html

---------------------------------------------------------------------------

Please cite the paper if you use our code :

Please cite the following paper if you use this code for research purpose:  
Jaiswal, S. P., Au, O. C., Jakhetiya, V., Guo, Y., Tiwari, A. K., &  Yue, K. �EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING,�
 in International conference on Image Processing (ICIP), page 4540 - 4544 . IEEE, (2013). 

---------------------------------------------------------------------------

