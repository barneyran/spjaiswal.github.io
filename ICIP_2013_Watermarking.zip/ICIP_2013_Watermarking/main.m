% Matlab code and data to reproduce results from the paper ::"EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING" .
% This software is provided for non-commercial and research purposes only.
% This code is written for the clarity of watermarking algorithm without considring the time complexity.
% Hope it will be useful, but without any warranty.

% Please cite the following paper if you use this code for research purpose:  
% Jaiswal, S. P., Au, O. C., Jakhetiya, V., Guo, Y., Tiwari, A. K., &  Yue, K. �EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING,�
% in International conference on Image Processing (ICIP), page 4540 - 4544 . IEEE, (2013). 

% Latest modifications: September, 2013.                     


%% 

clear all
close all
I = double(imread(input('give image-->')));  %2-D input
% 
Q = 1; % Q=1 implies Single Layer embedding, Q>1 is for Multi-layer embedding. If Q increases, capacity increases but PSNR decreases..

tic        % Time counting starts
%% Prediction and watermarking of first stage : even - even position
 ee_pred = I;
 
 pred = prediction(I,1);                            %% prediction is the prediction technique. Second argument refers to prediction of even-even position pixels 
 
 
for i=2:511                  
    for j=2:511
        
        if mod(i,2)==0 && mod(j,2) ==0              % EVEN - even position

             ee_pred(i,j) = pred(i,j);
        end

    end
end

  % EMBEDDING
 [ee_w ee]= OP_embed(I,ee_pred,1,Q);              %% OP_emebd is the watermarking technique. Third argument refers to watermarking of even-even position pixels
 
 %% Prediction and Watermarking of Second stage - Even Odd position pixels

 eo_pred = ee_w;

 pred = prediction(ee_w,2);                   %% prediction is the prediction technique. Second argument refers to prediction of even-odd position pixels 
for i=2:511                  
    for j=2:511
        
        if mod(i,2)==0 && mod(j,2) ==1                % EVEN - odd

            pred(i,j) =round((ee_w(i-1,j)+ ee_w(i,j-1)+ ee_w(i,j+1)+ ee_w(i+1,j))/4); 
            eo_pred(i,j) = pred(i,j);
        end

    end
end
  
  
  
  % EMBEDDING
 [eo_w eo]= OP_embed(I,eo_pred,2,Q);            %% OP_emebd is the watermarking technique. Third argument refers to watermarking of even-even position pixels


%% Prediction and Watermarking of Third stage - Odd Even

 oe_pred = eo_w;
 pred = prediction(eo_w,3);              %% prediction is the prediction technique. Second argument refers to prediction of odd-even position pixels 
for i=2:511                  
    for j=2:511
        
        if mod(i,2)==1 && mod(j,2) ==0                % odd - even

            pred(i,j) =round((eo_w(i-1,j)+ eo_w(i,j-1)+ eo_w(i,j+1)+ eo_w(i+1,j))/4); 
            oe_pred(i,j) = pred(i,j);
        end

    end
end

  
  % EMBEDDING
 [oe_w oe]= OP_embed(I,oe_pred,3,Q);          %% OP_emebd is the watermarking technique. Third argument refers to watermarking of odd-even position pixels


 
%% Prediction and Watermarking of Fourth stage - Odd Odd

 oo_pred = oe_w;
 pred = prediction(oe_w,4);           %% prediction is the prediction technique. Second argument refers to prediction of odd-odd position pixels 
 
 for i=2:511                  
    for j=2:511
        
        if mod(i,2)==1 && mod(j,2) ==1              % odd - odd

            pred(i,j) =round((oe_w(i-1,j)+ oe_w(i,j-1)+ oe_w(i,j+1)+ oe_w(i+1,j))/4); 
            oo_pred(i,j) = pred(i,j);
        end

    end
end

  % EMBEDDING
 [oo_w oo]= OP_embed(I,oo_pred,4,Q);          %% OP_emebd is the watermarking technique. Third argument refers to watermarking of odd-odd position pixels

 toc                  % Time counting stops
 %% Simulation Result
 
 Payload_capacity = oo+oe+ee+eo

 final_watermarked_psnr = PSNR(I,oo_w)
 
