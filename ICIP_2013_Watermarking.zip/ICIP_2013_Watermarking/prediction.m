% Matlab code and data to reproduce results from the paper ::"EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING" .
% This software is provided for non-commercial and research purposes only.
% This code is written for the clarity of watermarking algorithm without considring the time complexity.
% Hope it will be useful, but without any warranty.

% Please cite the following paper if you use this code for research purpose:  
% Jaiswal, S. P., Au, O. C., Jakhetiya, V., Guo, Y., Tiwari, A. K., &  Yue, K. �EFFICIENT ADAPTIVE PREDICTION BASED REVERSIBLE IMAGE WATERMARKING,�
% in International conference on Image Processing (ICIP), page 4540 - 4544 . IEEE, (2013). 

% Latest modifications: September, 2013.                     


%% 

function predict_image = prediction(I,kk)

 predict_image = double(zeros(512,512));

 v=0;
 
 if (kk==1)                              %% Prediction for EVEN-EVEN position Pixel
     
        for i=2:511
            for j=2:511
        
                 if mod(i,2) == 0 && mod(j,2) == 0
                     
                      A_0 = round((I(i,j-1)+I(i,j+1))/2);
                      A_45 = round((I(i-1,j+1)+I(i+1,j-1))/2);
                      A_90 = round((I(i-1,j)+I(i+1,j))/2);
                      A_135 = round((I(i-1,j-1)+I(i+1,j+1))/2);

                      a = [I(i,j-1),I(i,j+1),A_0];
                      var_0 = var(a);
 
                      b = [I(i-1,j+1),I(i+1,j-1),A_45];
                      var_45 = var(b);
      
                      c = [I(i-1,j),I(i+1,j),A_90];
                      var_90 = var(c);

                      d = [I(i-1,j-1),I(i+1,j+1),A_135];
                      var_135 = var(d);

                      sum = var_0*var_45*var_135 + var_0*var_45*var_90 + var_0*var_90*var_135  + var_90*var_45*var_135 ;




                      if  var_0==0 || var_45==0 || var_90==0 || var_135==0 || sum==0
                           alpha_0 =0.25;
                           alpha_45 = 0.25;
                           alpha_90 = 0.25;
                           alpha_135 = 0.25;   
                           v=v+1;  
                      else
         
         
                            alpha_90 = (var_0*var_45*var_135)/sum;
                            alpha_135 = (var_0*var_45*var_90)/sum;
                            alpha_45 = (var_0*var_90*var_135)/sum;
                            alpha_0 = (var_90*var_45*var_135)/sum;

                      end
        
        
                        predict_image(i,j) = round((alpha_0*A_0 + alpha_45*A_45 + alpha_90*A_90 + alpha_135*A_135)) ;

                 end
            end
    
       end

 else
     
        if (kk == 2)

             for i=2:511
                for j=2:511
        
                    if mod(i,2) == 0 && mod(j,2) == 1
                            A_0 = round((I(i,j-1)+I(i,j+1))/2);
                            A_45 = round((I(i-1,j+1)+I(i+1,j-1))/2);
                            A_90 = round((I(i-1,j)+I(i+1,j))/2);
                            A_135 = round((I(i-1,j-1)+I(i+1,j+1))/2);

                         a = [I(i,j-1),I(i,j+1),A_0];
                         var_0 = var(a);
 
                         b = [I(i-1,j+1),I(i+1,j-1),A_45];
                         var_45 = var(b);
      
                         c = [I(i-1,j),I(i+1,j),A_90];
                         var_90 = var(c);

                         d = [I(i-1,j-1),I(i+1,j+1),A_135];
                         var_135 = var(d);

                         sum = var_0*var_45*var_135 + var_0*var_45*var_90 + var_0*var_90*var_135  + var_90*var_45*var_135 ;




                          if  var_0==0 || var_45==0 || var_90==0 || var_135==0 || sum==0
                               alpha_0 =0.25;
                               alpha_45 = 0.25;
                               alpha_90 = 0.25;
                               alpha_135 = 0.25;   
                               v=v+1;  
                          else
         
         
                                alpha_90 = (var_0*var_45*var_135)/sum;
                                alpha_135 = (var_0*var_45*var_90)/sum;
                                alpha_45 = (var_0*var_90*var_135)/sum;
                                alpha_0 = (var_90*var_45*var_135)/sum;

                          end
        
        
                          predict_image(i,j) = round((alpha_0*A_0 + alpha_45*A_45 + alpha_90*A_90 + alpha_135*A_135)) ;

                    end
                end    
             end
            
        else
              if (kk==3)
         
         for i=2:511
    for j=2:511
        
  if mod(i,2) == 1 && mod(j,2) == 0
        A_0 = round((I(i,j-1)+I(i,j+1))/2);
A_45 = round((I(i-1,j+1)+I(i+1,j-1))/2);
A_90 = round((I(i-1,j)+I(i+1,j))/2);
A_135 = round((I(i-1,j-1)+I(i+1,j+1))/2);

        a = [I(i,j-1),I(i,j+1),A_0];
var_0 = var(a);
 
        b = [I(i-1,j+1),I(i+1,j-1),A_45];
var_45 = var(b);
      
        c = [I(i-1,j),I(i+1,j),A_90];
var_90 = var(c);

        d = [I(i-1,j-1),I(i+1,j+1),A_135];
var_135 = var(d);

sum = var_0*var_45*var_135 + var_0*var_45*var_90 + var_0*var_90*var_135  + var_90*var_45*var_135 ;




     if  var_0==0 || var_45==0 || var_90==0 || var_135==0 || sum==0
           alpha_0 =0.25;
           alpha_45 = 0.25;
           alpha_90 = 0.25;
           alpha_135 = 0.25;   
         v=v+1;  
     else
         
         
alpha_90 = (var_0*var_45*var_135)/sum;
alpha_135 = (var_0*var_45*var_90)/sum;
alpha_45 = (var_0*var_90*var_135)/sum;
alpha_0 = (var_90*var_45*var_135)/sum;

     end
        
        
        predict_image(i,j) = round((alpha_0*A_0 + alpha_45*A_45 + alpha_90*A_90 + alpha_135*A_135)) ;

  end
    end
    
         end
     else if kk==4
         
         for i=2:511
    for j=2:511
        
  if mod(i,2) == 1 && mod(j,2) == 1
        A_0 = round((I(i,j-1)+I(i,j+1))/2);
A_45 = round((I(i-1,j+1)+I(i+1,j-1))/2);
A_90 = round((I(i-1,j)+I(i+1,j))/2);
A_135 = round((I(i-1,j-1)+I(i+1,j+1))/2);

        a = [I(i,j-1),I(i,j+1),A_0];
var_0 = var(a);
 
        b = [I(i-1,j+1),I(i+1,j-1),A_45];
var_45 = var(b);
      
        c = [I(i-1,j),I(i+1,j),A_90];
var_90 = var(c);

        d = [I(i-1,j-1),I(i+1,j+1),A_135];
var_135 = var(d);

sum = var_0*var_45*var_135 + var_0*var_45*var_90 + var_0*var_90*var_135  + var_90*var_45*var_135 ;




     if  var_0==0 || var_45==0 || var_90==0 || var_135==0 || sum==0
           alpha_0 =0.25;
           alpha_45 = 0.25;
           alpha_90 = 0.25;
           alpha_135 = 0.25;   
         v=v+1;  
     else
         
         
alpha_90 = (var_0*var_45*var_135)/sum;
alpha_135 = (var_0*var_45*var_90)/sum;
alpha_45 = (var_0*var_90*var_135)/sum;
alpha_0 = (var_90*var_45*var_135)/sum;

     end
        
        
        predict_image(i,j) = round((alpha_0*A_0 + alpha_45*A_45 + alpha_90*A_90 + alpha_135*A_135)) ;
  end
  
    end
         end
         end
         end
     end
 end


% equal_weightage = v


end