function o_put = MED(input_image)

% input_image=double(input_image);
[row col]=size(input_image);
error_image=zeros(row,col);

%%%%%%%%%%%storing first col and row of image%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
error_image(1,1)=input_image(1,1);
for i=2:row
    error_image(i,1)=input_image(i,1)-input_image(i-1,1);
end
for j=2:col
    error_image(1,j)=input_image(1,j)-input_image(1,j-1);
end

for i=2:row
    for j=2:col
        N=input_image(i-1,j);
        W=input_image(i,j-1);
        NW=input_image(i-1,j-1);
        if(NW>=max(N,W))
            error_image(i,j)=input_image(i,j)-min(N,W);
        else if(NW<=min(N,W))
                 error_image(i,j)=input_image(i,j)-max(N,W);
            else
                error_image(i,j)=input_image(i,j)-(N+W-NW);
            end
        end
    end
end

%calculation of entropy of error_image
% error_hist_pos=zeros(1,255);
% error_hist_neg=zeros(1,255);
% error_hist_zero=0;
% for i=1:row
%    for j=1:col
%        if (error_image(i,j)<0)
%             error_hist_neg(abs(error_image(i,j)))=error_hist_neg(abs(error_image(i,j)))+1;
%        else if (error_image(i,j)>0)
%             error_hist_pos(error_image(i,j))=error_hist_pos(error_image(i,j))+1;
%         else 
%             error_hist_zero=error_hist_zero+1;
%            end
%        end
%    end
% end
% error_hist=[error_hist_neg error_hist_zero error_hist_pos];
% %plot(error_hist);
% prob=error_hist/(row*col);
% 
% for i=1:511
%    if(prob(i)==0)
%        prob(i)=1;
%    end
% end
% logprob=log2(prob);
% for i=1:511
%    if(prob(i)==1)
%        prob(i)=0;
%    end
% end
% med_entropy=-1*prob.*logprob;
%  (sum(med_entropy))
o_put = input_image-error_image;
end