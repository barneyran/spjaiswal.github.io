%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       ������֮֡���PSNR       
%%       author: ������ ( ganzongliang@hotmail )  
%%       Data:   2006��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SNR = PSNR(FrameOne,FrameTwo);

FrameOne = double(FrameOne);
FrameTwo = double(FrameTwo);
FrameOne = imcrop(FrameOne,[3 3 507 507]);
FrameTwo = imcrop(FrameTwo,[3 3 507 507]);
[w,h]=size(FrameOne);
MSE = sum((FrameOne(:)-FrameTwo(:)).^2);
TotalPixel = w*h;
[w h];
SNR = 10 * log10((255 * 255) / (MSE /TotalPixel));
