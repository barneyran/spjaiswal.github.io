Author:

Sunil Jaiswal
Dept. of ECE, HKUST, Hong Kong
Email:spjaiswal@ust.hk

---------------------------------------------------------------------------

1) run file : main.m

2) In main.m , oo_w is the final watermarked image
---------------------------------------------------------------------------

Project page : http://ihome.ust.hk/~spjaiswal/reversible_watermarking.html

---------------------------------------------------------------------------

% Please cite the following paper if you use this code for research purpose:  
% Sunil Prasad Jaiswal, Oscar C. Au, Vinit Jakhetiya, Yuanfang Guo, Anil K. Tiwari "Adaptive Predictor Structure Based Interpolation for Reversible Data Hiding ,
%" Proc. of International Workshop on Digital-forensics and Watermarking (IWDW), pp 276-288, 1-4 Oct. 2014

---------------------------------------------------------------------------

