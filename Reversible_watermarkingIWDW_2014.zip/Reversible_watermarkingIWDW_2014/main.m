% Matlab code and data to reproduce results from the paper ::"Adaptive Predictor Structure Based Interpolation for Reversible Data Hiding " .
% This software is provided for non-commercial and research purposes only.
% This code is written for the clarity of watermarking algorithm without considring the time complexity.
% Hope it will be useful, but without any warranty.

% Please cite the following paper if you use this code for research purpose:  
% Sunil Prasad Jaiswal, Oscar C. Au, Vinit Jakhetiya, Yuanfang Guo, Anil K. Tiwari "Adaptive Predictor Structure Based Interpolation for Reversible Data Hiding ,
%" Proc. of International Workshop on Digital-forensics and Watermarking (IWDW), pp 276-288, 1-4 Oct. 2014

% Latest modifications: November, 2014.      

clear all
input_im=imread(input('give image'));

input_im=double(input_im);

[m n]=size(input_im);

Q = 1; % Q=1 implies Single Layer embedding, Q>1 is for Multi-layer embedding. If Q increases, capacity increases but PSNR decreases..
tic %% the time starts now....Initialization

%% Prediction and Watermarking of First stage - EE
ee_pred = input_im;
pred = prediction(input_im);
% Copying Even-even Pixel to make predicted watermarked image
for i=2:511
    for j=2:511
        if mod(i,2) == 0 && mod(j,2) == 0
            ee_pred(i,j) = pred(i,j);
        end
    end
end

% EMBEDDING
[ee_w ee]= OP_embed(input_im,ee_pred,1,Q);   %% OP_emebd is the watermarking technique. Third argument refers to watermarking of even-even position pixels

%% Prediction and Watermarking of Second stage - EO

eo_pred = ee_w;
pred = prediction(ee_w);


% Copying even-odd Pixel to make predicted watermarked image
for i=2:511
    for j=2:511
        if mod(i,2) == 0 && mod(j,2) ~= 0
            eo_pred(i,j) = pred(i,j);
        end
    end
end

% EMBEDDING
[eo_w eo]= OP_embed(input_im,eo_pred,2,Q);   %% OP_emebd is the watermarking technique. Third argument refers to watermarking of even-odd position pixels



%% Prediction and Watermarking of Second stage - OE
oe_pred = eo_w;
pred = prediction(eo_w);

% Copying odd-even Pixel to make predicted watermarked image
for i=2:511
    for j=2:511
        if mod(i,2) ~= 0 && mod(j,2) == 0
            oe_pred(i,j) = pred(i,j);
        end
    end
end

% EMBEDDING
[oe_w oe]= OP_embed(input_im,oe_pred,3,Q);   %% OP_emebd is the watermarking technique. Third argument refers to watermarking of odd-even position pixels



%% Prediction and Watermarking of Second stage - OO

oo_pred = oe_w;
pred = prediction(oe_w);

% Copying odd-odd Pixel to make predicted watermarked image
for i=2:511
    for j=2:511
        if mod(i,2) ~= 0 && mod(j,2) ~= 0
            oo_pred(i,j) = pred(i,j);
        end
    end
end

% EMBEDDING
[oo_w oo]= OP_embed(input_im,oo_pred,4,Q);  %% OP_emebd is the watermarking technique. Third argument refers to watermarking of odd-odd position pixels
final_watermarked_image = oo_w;
%% results
Total_payload_capacity = (oo+oe+ee+eo)

final_watermarked_psnr = PSNR(input_im,final_watermarked_image)

