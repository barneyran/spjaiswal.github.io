function op = prediction(input_im)

%Just to make the programme slow, we divided the image into many blocks and we kept the prediction order 8 for each stage..

PP=64;
 row=512;
 col=512;

  y = MED(input_im); % This is just to fill boundary pixels by using an existing method MED (median edge detection algorithm by Prof Xiaolin Wu)
 
 for I=2:PP:511
    for J=2:PP:511
        
mat1=0;
mat2=0;
mat3=0;
mat4=0;
mat5=0;
mat6=0;
mat7=0;
mat8=0;

for i=I:I+PP-1
    for j=J:J+PP-1     
        
        
        if  i<row && j<col 
            
            
            
          a=input_im(i-1,j-1);          
          b=input_im(i-1,j);
          c=input_im(i-1,j+1);          
          d=input_im(i,j-1);
          e=input_im(i,j+1);
          f=input_im(i+1,j-1);
          g=input_im(i+1,j);
          h=input_im(i+1,j+1);
          X=input_im(i,j);
          
       d45=abs(a-b)+abs(b-c)+abs(d-e)+abs(f-h)+abs(g-h);
       
       d135=abs(a-d)+abs(d-f)+abs(b-g)+abs(c-e)+abs(e-h);

       D=d45-d135;
     %% First Bin

       if(D>40)       
            mat1=mat1+1;
         A=[a b c d e f g h ];
         matrix1(mat1,1:8)=A;
         data1(mat1)=X;         
      
       end
     %% Second  Bin
      
      if(D<=40 && D>32 )
                
         mat2=mat2+1;
         A=[a b c d e f g h ];
         matrix2(mat2,1:8)=A;
         data2(mat2)=X;
      
      end

     %% Third Bin
          if (D<=32 && D>8)
        
         mat3=mat3+1;
         A=[a b c d e f g h ];
         matrix3(mat3,1:8)=A;
         data3(mat3)=X;
        
          end
     %% Fouth Bin
     if (D<= 8 && D>=-8)
        
         mat4=mat4+1;
         A=[a b c d e f g h ];
         matrix4(mat4,1:8)=A;
         data4(mat4)=X;
    
     
     end
     %% Fifth Bin
     if(D>-32&& D<-8)
     
         mat5=mat5+1;
         A=[a b c d e f g h ];
         matrix5(mat5,1:8)=A;
         data5(mat5)=X; 
   
     end
     %% Sixth Bin
     
      if (D> -40 && D<= -32)
             mat6=mat6+1;
         A=[a b c d e f g h ];
         matrix6(mat6,1:8)=A;
         data6(mat6)=X;
         
      end
      
      %% Seventh Bin
              if (D<=-40)

         mat7=mat7+1;
         A=[a b c d e f g h ];
         matrix7(mat7,1:8)=A;
         data7(mat7)=X;
     
              end
             
%                    %% Seventh Bin
%               if (D<=-40)
% 
%          mat7=mat7+1;
%          A=[a b c d e f g h ];
%          matrix7(mat7,1:8)=A;
%          data7(mat7)=X;
%      
%              end
 
         end
 
     end
   
end 


    
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETER ESTIMATION    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%
  %% First parameter calculations
  if mat1>0
 V=eye(8,8);
 e1=inv(matrix1'*matrix1+0.5*V)*matrix1'*data1';
  else
      e1(1:8)=.125;
  end
 %% Second parameter calculations
  if mat2>0
   V=eye(8,8);
 e2=inv(matrix2'*matrix2+0.5*V)*matrix2'*data2';
  else
      e2(1:8)=1/8;
  end
 %% Third parameter calculations
if mat3>0
 V=eye(8,8);
 e3=inv(matrix3'*matrix3+0.5*V)*matrix3'*data3';
else 
    e3(1:8)=1/8;
end
 %% fourth parameters calculation
 if mat4>0
        V=eye(8,8);
 e4=inv(matrix4'*matrix4+0.5*V)*matrix4'*data4';
 else
     e4(1:8)=1/8;
 end
  %% fifth parameters calculation
 if mat5>0
   V=eye(8,8);
 e5=inv(matrix5'*matrix5+0.5*V)*matrix5'*data5';
 else
     e5(1:8)=1/8;
 end
   %% sixth parameters calculation
 if mat6>0
   V=eye(8,8);
 e6=inv(matrix6'*matrix6+0.5*V)*matrix6'*data6';
 else
     e6(1:8)=1/8;
 end
    %% seventh parameters calculation
    if mat7>0
            V=eye(8,8);
 e7=inv(matrix7'*matrix7+0.5*V)*matrix7'*data7';
    else e7(1:8)=1/8;
    end
    
       %% %%%%%%%%%%%%%%%%%%%%%%%%%%   PARAMETER IMPLEMENTATION %%%%%%
       
for i=I:I+PP-1
    for j=J:J+PP-1
          if  i<row && j<col
              
          a=input_im(i-1,j-1);          
          b=input_im(i-1,j);
          c=input_im(i-1,j+1);          
          d=input_im(i,j-1);
          e=input_im(i,j+1);
          f=input_im(i+1,j-1);
          g=input_im(i+1,j);
          h=input_im(i+1,j+1);
        %  X=input_im(i,j);
          
        d45=abs(a-b)+abs(b-c)+abs(d-e)+abs(f-h)+abs(g-h);       
        d135=abs(a-d)+abs(d-f)+abs(b-g)+abs(c-e)+abs(e-h);
       
         D=d45-d135;
        
         %% First
     if(D>40)
   
         if sum(e1)>5 || sum(e1)<.5
             e1(1:8)=1/8;
         end
  y(i,j)=round(e1(1)*a+e1(2)*b+e1(3)*c+e1(4)*d+e1(5)*e+e1(6)*f+e1(7)*g+e1(8)*h);
     end
  
     %% Second
        if(D<=40 && D>32 )
   
             if sum(e2)>5|| sum(e2)<.5
             e2(1:8)=1/8;
             end
         y(i,j)=round(e2(1)*a+e2(2)*b+e2(3)*c+e2(4)*d+e2(5)*e+e2(6)*f+e2(7)*g+e2(8)*h);
  
        end
        
        %% Third
           if (D<=32 && D>8)
           if sum(e3)>5 || sum(e3)<.5
             e3(1:8)=1/8;
           end
  y(i,j)=round(e3(1)*a+e3(2)*b+e3(3)*c+e3(4)*d+e3(5)*e+e3(6)*f+e3(7)*g+e3(8)*h);
  
           end
       
           %% Fourth
                if (D<= 8 && D>=-8)
    if sum(e4)>5 || sum(e4)<.5
             e4(1:8)=1/8;
    end
  y(i,j)=round(e4(1)*a+e4(2)*b+e4(3)*c+e4(4)*d+e4(5)*e+e4(6)*f+e4(7)*g+e4(8)*h);
  
                end
                 
                %% Fifth
                
                
                     if(D>-32&& D<-8)
    if sum(e5)>5|| sum(e5)<.5
             e5(1:8)=1/8;
    end
  y(i,j)=round(e5(1)*a+e5(2)*b+e5(3)*c+e5(4)*d+e5(5)*e+e5(6)*f+e5(7)*g+e5(8)*h);
  
                     end
                      
                     %% Sixth
                            if(D> -40 && D<= -32)
    if sum(e6)>5 || sum(e6)<.5
             e6(1:8)=1/8;
    end
  y(i,j)=round(e6(1)*a+e6(2)*b+e6(3)*c+e6(4)*d+e6(5)*e+e6(6)*f+e6(7)*g+e6(8)*h);
  
                            end
                          
                            %% Seventh
                            
                           if(D<=-40)
    if sum(e7)>5 || sum(e7)<.5
             e7(1:8)=1/8;
    end
  y(i,j)=round(e7(1)*a+e7(2)*b+e7(3)*c+e7(4)*d+e7(5)*e+e7(6)*f+e7(7)*g+e7(8)*h);
  
                           end
          end
    end
end
 
    end
    
 end
 
 
%  %% Counting -Time Pass
%  y = round(y);
%  input_im = round(input_im);
% 
%  for i=2:511
%      for j=2:511
%      if (input_im(i,j) - y(i,j)) == 0 || (input_im(i,j) - y(i,j)) == -1
%        
%             count = count +1;
%      end
%            
%                if (input_im(i,j) - y(i,j)) == 0 || (input_im(i,j) - y(i,j)) == 1
%        
%             count1 = count1 +1;
%                end
%                
%      end
%  end
% 
%  %% PSNR  and PL
% psnr =  PSNR(y,input_im)
%  pl = count
%  pl1=count1
% 
% toc
 op = round(y);
end
